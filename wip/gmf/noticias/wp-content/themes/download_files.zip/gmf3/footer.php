<div id="footer">
    	<div id="footernav">
        	<a href="http://www.gmfsaneamento.com.br/faleconosco.html"><font class="footerp">Fale Conosco</p></a>
           <!--<a href="http://www.gmfsaneamento.com.br/acesso.html">
            <font class="footerp">Acesso Restrito</p></a>!-->
        </div>
        <div class="barrav">&#124;</div>
        <div id="footernav2">
        	<font class="footerp">Av. Paulista nº 2644 – 7º andar – Bela Vista – São Paulo/SP CEP: 01310-300<br />
Fone 55 11 2626-8329</p>
        </div>
        
    </div>
</div>
</div><?php wp_footer(); ?>
</body>
</html>